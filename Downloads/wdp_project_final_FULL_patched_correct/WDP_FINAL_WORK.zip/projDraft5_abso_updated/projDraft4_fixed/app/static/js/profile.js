﻿// Profile Page Tab Switching

function demoHeaders(extra) {
  const headers = extra ? { ...extra } : {};
  const demoId = sessionStorage.getItem('demo_user_id');
  if (demoId) headers['X-Demo-User'] = demoId;
  return headers;
}

document.addEventListener('DOMContentLoaded', function() {
  const tabBtns = document.querySelectorAll('.profile-tab-btn');
  const tabContents = document.querySelectorAll('.profile-tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const tabName = this.dataset.tab;

      // Remove active from all
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      // Add active to clicked
      this.classList.add('active');
      const targetContent = document.getElementById(`tab-${tabName}`);
      if (targetContent) {
        targetContent.classList.add('active');
      }

      // Scroll to top
      window.scrollTo({ top: 200, behavior: 'smooth' });
    });
  });

  // Load profile data
  loadProfile();

  // Edit Bio functionality
  const editBioBtn = document.getElementById('edit-bio-btn');
  if (editBioBtn) {
    editBioBtn.addEventListener('click', function() {
      const bioText = document.getElementById('bio-text');
      if (!bioText) return;

      const currentBio = bioText.textContent || '';
      const textarea = document.createElement('textarea');
      textarea.value = currentBio;
      textarea.className = 'bio-edit-textarea';
      textarea.rows = 4;
      textarea.style.width = '100%';
      textarea.style.marginBottom = '10px';

      const saveBtn = document.createElement('button');
      saveBtn.textContent = 'Save';
      saveBtn.className = 'btn bio-save-btn';

      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancel';
      cancelBtn.className = 'btn btn-secondary bio-cancel-btn';

      const buttonContainer = document.createElement('div');
      buttonContainer.className = 'bio-action-buttons';
      buttonContainer.appendChild(saveBtn);
      buttonContainer.appendChild(cancelBtn);

      // Replace bio text with textarea and buttons
      bioText.style.display = 'none';
      editBioBtn.style.display = 'none';
      bioText.parentNode.insertBefore(textarea, bioText);
      bioText.parentNode.insertBefore(buttonContainer, bioText);

      saveBtn.addEventListener('click', function() {
        const newBio = textarea.value.trim();
        updateBio(newBio);
      });

      cancelBtn.addEventListener('click', function() {
        // Restore original
        textarea.remove();
        buttonContainer.remove();
        bioText.style.display = '';
        editBioBtn.style.display = '';
      });
    });
  }

  document.querySelector('.btn-danger')?.addEventListener('click', function() {
    if (confirm('\u26A0\uFE0F Are you SURE you want to delete your account? This action cannot be undone.')) {
      alert('Account deletion process initiated. You will receive a confirmation email.');
    }
  });

  const mediaModal = document.getElementById('media-choice-modal');
  const mediaAvatarEditBtn = document.getElementById('media-choice-avatar-edit');
  const mediaCameraBtn = document.getElementById('media-choice-camera');
  const mediaUploadBtn = document.getElementById('media-choice-upload');
  const mediaCancelBtn = document.getElementById('media-choice-cancel');
  let activeMediaTarget = null;

  function openMediaModal(target) {
    activeMediaTarget = target;
    if (mediaAvatarEditBtn) {
      mediaAvatarEditBtn.style.display = target === 'avatar' ? '' : 'none';
    }
    if (mediaModal) {
      mediaModal.classList.add('show');
      mediaModal.setAttribute('aria-hidden', 'false');
    }
  }

  function closeMediaModal() {
    activeMediaTarget = null;
    if (mediaModal) {
      mediaModal.classList.remove('show');
      mediaModal.setAttribute('aria-hidden', 'true');
    }
  }

  if (mediaCancelBtn) mediaCancelBtn.addEventListener('click', closeMediaModal);
  if (mediaModal) {
    mediaModal.addEventListener('click', function (e) {
      if (e.target === mediaModal) closeMediaModal();
    });
  }

  const avatarBtn = document.getElementById('edit-avatar-btn');
  const bannerBtn = document.getElementById('edit-banner-btn');
  const avatarCamera = document.getElementById('avatar-input-camera');
  const avatarUpload = document.getElementById('avatar-input-upload');
  const bannerCamera = document.getElementById('banner-input-camera');
  const bannerUpload = document.getElementById('banner-input-upload');

  if (avatarBtn) avatarBtn.addEventListener('click', () => openMediaModal('avatar'));
  if (bannerBtn) bannerBtn.addEventListener('click', () => openMediaModal('banner'));

  if (mediaCameraBtn) {
    mediaCameraBtn.addEventListener('click', function () {
      if (activeMediaTarget === 'avatar' && avatarCamera) avatarCamera.click();
      if (activeMediaTarget === 'banner' && bannerCamera) bannerCamera.click();
      closeMediaModal();
    });
  }

  if (mediaUploadBtn) {
    mediaUploadBtn.addEventListener('click', function () {
      if (activeMediaTarget === 'avatar' && avatarUpload) avatarUpload.click();
      if (activeMediaTarget === 'banner' && bannerUpload) bannerUpload.click();
      closeMediaModal();
    });
  }

  if (mediaAvatarEditBtn) {
    mediaAvatarEditBtn.addEventListener('click', function () {
      closeMediaModal();
      window.location.href = '/signup-avatar?edit=1';
    });
  }

  async function handleAvatarUpload(input) {
    if (!input || !input.files || !input.files[0]) return;
    const form = new FormData();
    form.append('avatar', input.files[0]);
    const res = await fetch('/api/profile/avatar', { method: 'POST', headers: demoHeaders(), body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return alert(data.error || 'Could not upload avatar.');
    const img = document.getElementById('profile-avatar');
    if (img) img.src = data.url;
  }

  async function handleBannerUpload(input) {
    if (!input || !input.files || !input.files[0]) return;
    const form = new FormData();
    form.append('banner', input.files[0]);
    const res = await fetch('/api/profile/banner', { method: 'POST', headers: demoHeaders(), body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return alert(data.error || 'Could not upload banner.');
    const cover = document.getElementById('profile-cover');
    if (cover) cover.style.backgroundImage = `url('${data.url}')`;
  }

  if (avatarCamera) avatarCamera.addEventListener('change', () => handleAvatarUpload(avatarCamera));
  if (avatarUpload) avatarUpload.addEventListener('change', () => handleAvatarUpload(avatarUpload));
  if (bannerCamera) bannerCamera.addEventListener('change', () => handleBannerUpload(bannerCamera));
  if (bannerUpload) bannerUpload.addEventListener('change', () => handleBannerUpload(bannerUpload));

  const editTeach = document.getElementById('edit-skills-teach');
  if (editTeach) {
    editTeach.addEventListener('click', () => {
      window.location.href = '/onboarding?edit=1&step=3';
    });
  }

  const editLearn = document.getElementById('edit-skills-learn');
  if (editLearn) {
    editLearn.addEventListener('click', () => {
      window.location.href = '/onboarding?edit=1&step=4';
    });
  }

  const editInterests = document.getElementById('edit-interests');
  if (editInterests) {
    editInterests.addEventListener('click', () => {
      window.location.href = '/onboarding?edit=1&step=2';
    });
  }

  const editAvailability = document.getElementById('edit-availability');
  if (editAvailability) {
    editAvailability.addEventListener('click', () => {
      window.location.href = '/onboarding?edit=1&step=5';
    });
  }

  const safetyInfo = document.getElementById('safety-score-info');
  if (safetyInfo) {
    safetyInfo.addEventListener('click', () => {
      alert('Your Safety Score grows with positive activity (circles, good behavior) and drops with confirmed violations or no-shows.');
    });
  }

  let reportConnections = [];
  async function loadReportConnections() {
    const select = document.getElementById('report-connection');
    if (!select) return;
    try {
      const res = await fetch('/api/matches', { headers: demoHeaders() });
      const items = await res.json().catch(() => []);
      reportConnections = Array.isArray(items) ? items : [];
      select.innerHTML = '<option value="">Select connection</option>';
      reportConnections.forEach((row) => {
        const opt = document.createElement('option');
        opt.value = row.match_id;
        opt.textContent = row.location ? `${row.name} (${row.location})` : row.name;
        select.appendChild(opt);
      });
    } catch (_) {
      select.innerHTML = '<option value="">Select connection</option>';
    }
  }
  loadReportConnections();

  const reportBtn = document.getElementById('submit-report');
  if (reportBtn) {
    reportBtn.addEventListener('click', async () => {
      const selectedConnectionId = (document.getElementById('report-connection')?.value || '').trim();
      const selectedConnection = reportConnections.find((row) => row.match_id === selectedConnectionId);
      const reason = (document.getElementById('report-reason')?.value || '').trim();
      const date = (document.getElementById('report-date')?.value || '').trim();
      const details = (document.getElementById('report-details')?.value || '').trim();
      if (!reason || !date) return alert('Please select a reason and date.');
      const enrichedDetails = selectedConnection
        ? `Connection: ${selectedConnection.name} (${selectedConnection.match_id})\n${details}`
        : details;
      const res = await fetch('/api/report', {
        method: 'POST',
        headers: demoHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ reason: reason, incident_date: date, details: enrichedDetails })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not submit report.');
      alert('Report submitted. Our safety team will review it.');
      if (document.getElementById('report-connection')) document.getElementById('report-connection').value = '';
      if (document.getElementById('report-reason')) document.getElementById('report-reason').value = '';
      if (document.getElementById('report-date')) document.getElementById('report-date').value = '';
      if (document.getElementById('report-details')) document.getElementById('report-details').value = '';
    });
  }

  const blockBtn = document.getElementById('block-connection');
  if (blockBtn) {
    blockBtn.addEventListener('click', async () => {
      const selectedConnectionId = (document.getElementById('report-connection')?.value || '').trim();
      if (!selectedConnectionId) {
        alert('Select a connection first.');
        return;
      }
      const selectedConnection = reportConnections.find((row) => row.match_id === selectedConnectionId);
      const label = selectedConnection ? selectedConnection.name : selectedConnectionId;
      if (!confirm(`Block ${label}? This removes the match from your list.`)) return;
      const res = await fetch(`/api/matches/${encodeURIComponent(selectedConnectionId)}`, {
        method: 'DELETE',
        headers: demoHeaders(),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not block this connection.');
      alert('Connection blocked.');
      await loadReportConnections();
      loadProfile();
    });
  }

  const saveEmergency = document.getElementById('save-emergency');
  const verifyPhoneInput = document.getElementById('verify-phone-number');
  if (verifyPhoneInput) {
    verifyPhoneInput.addEventListener('input', () => {
      verifyPhoneInput.value = verifyPhoneInput.value.replace(/\D/g, '');
    });
  }
  const emergencyPhoneInput = document.getElementById('emergency-phone');
  if (emergencyPhoneInput) {
    emergencyPhoneInput.addEventListener('input', () => {
      emergencyPhoneInput.value = emergencyPhoneInput.value.replace(/\D/g, '');
    });
  }
  if (saveEmergency) {
    saveEmergency.addEventListener('click', async () => {
      const name = (document.getElementById('emergency-name')?.value || '').trim();
      const relationship = (document.getElementById('emergency-relationship')?.value || '').trim();
      const countryCode = (document.getElementById('emergency-country-code')?.value || '+65').trim();
      const phone = (document.getElementById('emergency-phone')?.value || '').replace(/\D/g, '');
      await saveProfile({ emergency_contact: { name, relationship, country_code: countryCode, phone } });
    });
  }

  const linkSingpass = document.getElementById('link-singpass');
  if (linkSingpass) {
    linkSingpass.addEventListener('click', async () => {
      await saveProfile({ verified_with: 'singpass' });
    });
  }
  const linkNric = document.getElementById('link-nric');
  if (linkNric) {
    linkNric.addEventListener('click', async () => {
      await saveProfile({ verified_with: 'nric' });
    });
  }

  const sendEmailVerify = document.getElementById('send-email-verify');
  if (sendEmailVerify) {
    sendEmailVerify.addEventListener('click', async () => {
      const res = await fetch('/api/verification/email/send', {
        method: 'POST',
        headers: demoHeaders({ 'Content-Type': 'application/json' }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not send email verification code.');
      const dev = document.getElementById('email-verify-dev-code');
      if (dev) {
        if (data.dev_code) {
          dev.value = data.dev_code;
          dev.style.display = '';
        } else {
          dev.value = '';
          dev.style.display = 'none';
        }
      }
      alert('Verification code sent to your email.');
    });
  }

  const confirmEmailVerify = document.getElementById('confirm-email-verify');
  if (confirmEmailVerify) {
    confirmEmailVerify.addEventListener('click', async () => {
      const code = (document.getElementById('email-verify-code')?.value || '').trim();
      const res = await fetch('/api/verification/email/verify', {
        method: 'POST',
        headers: demoHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ code }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not verify email.');
      alert('Email verified.');
      loadProfile();
    });
  }

  const sendPhoneVerify = document.getElementById('send-phone-verify');
  if (sendPhoneVerify) {
    sendPhoneVerify.addEventListener('click', async () => {
      const country_code = (document.getElementById('verify-phone-country')?.value || '+65').trim();
      const phone_number = (document.getElementById('verify-phone-number')?.value || '').replace(/\D/g, '');
      const res = await fetch('/api/verification/phone/send', {
        method: 'POST',
        headers: demoHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ country_code, phone_number }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not send phone verification code.');
      const dev = document.getElementById('phone-verify-dev-code');
      if (dev) {
        if (data.dev_code) {
          dev.value = data.dev_code;
          dev.style.display = '';
        } else {
          dev.value = '';
          dev.style.display = 'none';
        }
      }
      alert('Verification code sent to your phone.');
    });
  }

  const confirmPhoneVerify = document.getElementById('confirm-phone-verify');
  if (confirmPhoneVerify) {
    confirmPhoneVerify.addEventListener('click', async () => {
      const code = (document.getElementById('phone-verify-code')?.value || '').trim();
      const res = await fetch('/api/verification/phone/verify', {
        method: 'POST',
        headers: demoHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ code }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not verify phone.');
      alert('Phone verified.');
      loadProfile();
    });
  }

  ['notif-messages','notif-matches','notif-circles','notif-challenges','notif-badges',
   'privacy-age','privacy-location','privacy-badges','privacy-direct'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => {
        const notifications = {
          messages: !!document.getElementById('notif-messages')?.checked,
          matches: !!document.getElementById('notif-matches')?.checked,
          circles: !!document.getElementById('notif-circles')?.checked,
          challenges: !!document.getElementById('notif-challenges')?.checked,
          badges: !!document.getElementById('notif-badges')?.checked,
        };
        const privacy = {
          show_age: !!document.getElementById('privacy-age')?.checked,
          show_location: !!document.getElementById('privacy-location')?.checked,
          show_badges: !!document.getElementById('privacy-badges')?.checked,
          allow_direct: !!document.getElementById('privacy-direct')?.checked,
        };
        saveProfile({ notifications, privacy });
      });
    }
  });

  const MRT_STATIONS = [
    "Admiralty","Aljunied","Ang Mo Kio","Bartley","Bayfront","Beauty World","Bedok","Bedok North","Bedok Reservoir",
    "Bencoolen","Bendemeer","Bishan","Boon Keng","Boon Lay","Botanic Gardens","Braddell","Bras Basah","Bright Hill",
    "Bugis","Buona Vista","Buangkok","Bukit Batok","Bukit Gombak","Bukit Panjang","Caldecott","Canberra","Cashew",
    "Changi Airport","Chinatown","Choa Chu Kang","Chinese Garden","City Hall","Clarke Quay","Clementi","Commonwealth",
    "Dakota","Dhoby Ghaut","Dover","Downtown","Eunos","Expo","Farrer Park","Farrer Road","Fort Canning",
    "Gardens by the Bay","Geylang Bahru","Gul Circle","Great World","Havelock","Haw Par Villa","HarbourFront",
    "Hillview","Holland Village","Hougang","Jalan Besar","Joo Koon","Jurong East","Kaki Bukit","Kallang","Katong Park",
    "Kembangan","Kent Ridge","Khatib","King Albert Park","Kovan","Kranji","Labrador Park","Lakeside","Lavender",
    "Lentor","Little India","Lorong Chuan","MacPherson","Marina Bay","Marina South Pier","Marine Parade",
    "Marine Terrace","Marymount","Mattar","Maxwell","Mayflower","Mountbatten","Napier","Nicoll Highway","Novena",
    "one-north","Orchard","Orchard Boulevard","Outram Park","Pasir Panjang","Pasir Ris","Paya Lebar","Pioneer",
    "Potong Pasir","Promenade","Punggol","Queenstown","Raffles Place","Redhill","Rochor","Sembawang","Sengkang",
    "Serangoon","Shenton Way","Simei","Siglap","Sixth Avenue","Somerset","Springleaf","Stadium","Stevens","Tai Seng",
    "Tampines","Tampines East","Tampines West","Tan Kah Kee","Tanah Merah","Tanjong Katong","Tanjong Pagar",
    "Tanjong Rhu","Telok Ayer","Tiong Bahru","Toa Payoh","Tuas Crescent","Tuas Link","Tuas West Road",
    "Ubi","Upper Changi","Upper Thomson","Woodlands","Woodlands North","Woodlands South","Woodleigh","Yew Tee",
    "Yio Chu Kang","Yishun"
  ];
  const MRT_STATIONS_SORTED = MRT_STATIONS.slice().sort((a, b) => a.localeCompare(b));

  const MRT_LINE_GROUPS = [
    { key: "NSL", label: "North South", stations: ["Admiralty","Ang Mo Kio","Bishan","Braddell","Bukit Batok","Bukit Gombak","Canberra","Choa Chu Kang","City Hall","Dhoby Ghaut","Jurong East","Khatib","Kranji","Marina Bay","Marina South Pier","Novena","Orchard","Raffles Place","Sembawang","Somerset","Toa Payoh","Woodlands","Yew Tee","Yio Chu Kang","Yishun"] },
    { key: "EWL", label: "East West", stations: ["Aljunied","Bedok","Boon Lay","Bugis","Buona Vista","Changi Airport","Chinese Garden","City Hall","Clementi","Commonwealth","Dover","Eunos","Expo","Gul Circle","Joo Koon","Jurong East","Kallang","Kembangan","Lakeside","Lavender","Outram Park","Pasir Ris","Paya Lebar","Pioneer","Queenstown","Raffles Place","Redhill","Simei","Tanah Merah","Tanjong Pagar","Tiong Bahru","Tuas Crescent","Tuas Link","Tuas West Road"] },
    { key: "DTL", label: "Downtown", stations: ["Bayfront","Beauty World","Bedok North","Bedok Reservoir","Bencoolen","Bendemeer","Botanic Gardens","Bugis","Bukit Panjang","Cashew","Chinatown","Downtown","Expo","Fort Canning","Geylang Bahru","Hillview","Jalan Besar","Kaki Bukit","King Albert Park","Little India","MacPherson","Mattar","Promenade","Rochor","Sixth Avenue","Stevens","Tan Kah Kee","Telok Ayer","Tampines","Tampines East","Tampines West","Ubi","Upper Changi"] },
    { key: "NEL", label: "North East", stations: ["Boon Keng","Buangkok","Chinatown","Clarke Quay","Dhoby Ghaut","Farrer Park","HarbourFront","Hougang","Kovan","Little India","Outram Park","Potong Pasir","Punggol","Sengkang","Serangoon","Woodleigh"] },
    { key: "CCL", label: "Circle", stations: ["Bartley","Bayfront","Botanic Gardens","Bras Basah","Buona Vista","Caldecott","Dakota","Dhoby Ghaut","Farrer Road","HarbourFront","Haw Par Villa","Holland Village","Kent Ridge","Labrador Park","Lorong Chuan","MacPherson","Marina Bay","Marymount","Mountbatten","Nicoll Highway","one-north","Pasir Panjang","Promenade","Serangoon","Stadium","Tai Seng"] },
    { key: "TEL", label: "Thomson-East Coast", stations: ["Bright Hill","Caldecott","Gardens by the Bay","Great World","Havelock","Lentor","Marine Parade","Marine Terrace","Maxwell","Mayflower","Napier","Orchard Boulevard","Outram Park","Shenton Way","Siglap","Springleaf","Stevens","Tanjong Katong","Tanjong Rhu","Upper Thomson","Woodlands North","Woodlands South"] }
  ];

  const MRT_LINE_COLOR = {
    NSL: "#ef4444",
    EWL: "#22c55e",
    DTL: "#2563eb",
    NEL: "#a855f7",
    CCL: "#f59e0b",
    TEL: "#8b5e3c",
    OTHER: "#94a3b8"
  };

  const stationToLines = MRT_LINE_GROUPS.reduce((acc, group) => {
    group.stations.forEach((name) => {
      if (!acc[name]) acc[name] = [];
      if (!acc[name].includes(group.key)) acc[name].push(group.key);
    });
    return acc;
  }, {});

  let selectedStations = [];
  let activeLineFilter = "ALL";

  function stationLineKeys(stationName) {
    return stationToLines[stationName] && stationToLines[stationName].length
      ? stationToLines[stationName]
      : ["OTHER"];
  }

  function stationMarkerBackground(stationName) {
    const keys = stationLineKeys(stationName);
    const colors = keys.map((k) => MRT_LINE_COLOR[k] || MRT_LINE_COLOR.OTHER);
    if (colors.length === 1) return colors[0];
    const step = 100 / colors.length;
    return `linear-gradient(180deg, ${colors.map((c, i) => `${c} ${Math.round(i * step)}% ${Math.round((i + 1) * step)}%`).join(', ')})`;
  }

  function renderLineFilters() {
    const wrap = document.getElementById('profile-mrt-line-filters');
    if (!wrap) return;
    wrap.innerHTML = '';
    const allBtn = document.createElement('button');
    allBtn.type = 'button';
    allBtn.className = 'profile-line-filter' + (activeLineFilter === 'ALL' ? ' active' : '');
    allBtn.textContent = 'All Lines';
    allBtn.addEventListener('click', () => {
      activeLineFilter = 'ALL';
      renderLineFilters();
      filterProfileStations(document.getElementById('profile-mrt-search')?.value || '');
    });
    wrap.appendChild(allBtn);
    MRT_LINE_GROUPS.forEach((line) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'profile-line-filter' + (activeLineFilter === line.key ? ' active' : '');
      btn.innerHTML = `<span class="profile-line-dot" style="background:${MRT_LINE_COLOR[line.key]};"></span>${line.label}`;
      btn.addEventListener('click', () => {
        activeLineFilter = line.key;
        renderLineFilters();
        filterProfileStations(document.getElementById('profile-mrt-search')?.value || '');
      });
      wrap.appendChild(btn);
    });
  }

  function renderProfileStations(list) {
    const container = document.getElementById('profile-mrt-options');
    if (!container) return;
    container.innerHTML = '';
    list.forEach(function (name) {
      const id = 'profile-mrt-' + name.replace(/\s+/g, '-').toLowerCase();
      const checked = selectedStations.indexOf(name) !== -1 ? 'checked' : '';
      const item = document.createElement('label');
      item.className = 'station-option';
      item.innerHTML = `
        <span class="station-line-marker" style="background:${stationMarkerBackground(name)};"></span>
        <input type="checkbox" class="profile-station-checkbox" id="${id}" value="${name}" ${checked}>
        <span>${name}</span>
      `;
      container.appendChild(item);
    });

    container.querySelectorAll('.profile-station-checkbox').forEach(function (cb) {
      cb.addEventListener('change', function () {
        const val = cb.value;
        if (cb.checked) {
          if (selectedStations.indexOf(val) === -1) selectedStations.push(val);
        } else {
          selectedStations = selectedStations.filter(s => s !== val);
        }
      });
    });
  }

  function filterProfileStations(query) {
    const q = (query || '').toLowerCase();
    const filtered = MRT_STATIONS_SORTED.filter((stationName) => {
      if (!stationName.toLowerCase().includes(q)) return false;
      if (activeLineFilter === 'ALL') return true;
      return stationLineKeys(stationName).includes(activeLineFilter);
    });
    renderProfileStations(filtered);
  }

  const profileSearch = document.getElementById('profile-mrt-search');
  if (profileSearch) {
    profileSearch.addEventListener('input', function () {
      filterProfileStations(profileSearch.value);
    });
  }

  const profileSave = document.getElementById('profile-mrt-save-btn');
  if (profileSave) {
    profileSave.addEventListener('click', async () => {
      const name = selectedStations.join(', ');
      await saveProfile({ location_name: name });
      const display = document.getElementById('location-display');
      if (display && name) display.textContent = `\u{1F4CD} ${name}`;
    });
  }

  window.__setProfileStations = function (stations) {
    selectedStations = Array.isArray(stations) ? stations.slice() : [];
    renderLineFilters();
    filterProfileStations(document.getElementById('profile-mrt-search')?.value || '');
  };
});

function loadProfile() {
  fetch('/api/profile', { headers: (typeof demoHeaders === 'function' ? demoHeaders() : {}) })
    .then(response => response.json())
    .then(data => {
      if (data.ok) {
        const profile = data.profile;
        const bioText = document.getElementById('bio-text');
        if (bioText) {
          bioText.textContent = profile.bio || '';
        }
        const connections = document.getElementById('connections-count');
        if (connections) connections.textContent = profile.connections_count ?? 0;
        const memories = document.getElementById('memories-count');
        if (memories) memories.textContent = profile.memories_count ?? 0;
        const repoints = document.getElementById('repoints-count');
        if (repoints) repoints.textContent = profile.repoints ?? 0;
        const completeness = document.getElementById('profile-completeness');
        if (completeness) {
          const c = profile.completeness || {};
          const percent = Number(c.percent || 0);
          const completed = Number(c.completed || 0);
          const total = Number(c.total || 0);
          completeness.textContent = `Profile completeness: ${percent}% (${completed}/${total})`;
        }

        const avatar = document.getElementById('profile-avatar');
        if (avatar && profile.avatar_url) avatar.src = profile.avatar_url;
        const cover = document.getElementById('profile-cover');
        if (cover && profile.banner_url) cover.style.backgroundImage = `url('${profile.banner_url}')`;

        const locDisplay = document.getElementById('location-display');
        const onboardingStations = Array.isArray(profile.onboarding?.stations) ? profile.onboarding.stations : [];
        const storedStations = profile.location_name
          ? profile.location_name.split(',').map(s => s.trim()).filter(Boolean)
          : [];
        const stationList = onboardingStations.length ? onboardingStations : storedStations;
        if (locDisplay && stationList.length) locDisplay.textContent = `\u{1F4CD} ${stationList.join(', ')}`;
        if (stationList.length && typeof window.__setProfileStations === 'function') {
          window.__setProfileStations(stationList);
        } else if (typeof window.__setProfileStations === 'function') {
          window.__setProfileStations([]);
        }
        const interests = Array.isArray(profile.onboarding?.interests) ? profile.onboarding.interests : [];
        const interestMap = {
          technology: '💻 Technology',
          cooking: '🍳 Cooking',
          gardening: '🌱 Gardening',
          music: '🎵 Music',
          art: '🎨 Arts & Crafts',
          reading: '📚 Reading',
          fitness: '💪 Fitness',
          photography: '📷 Photography',
          travel: '✈️ Travel',
          games: '🎮 Games',
          language: '🗣️ Languages',
          volunteering: '🤝 Volunteering'
        };
        const interestsWrap = document.querySelector('.interest-tags');
        if (interestsWrap) {
          if (interests.length) {
            interestsWrap.innerHTML = interests.map(i => `<span class="interest-tag">${interestMap[i] || escapeHtml(i)}</span>`).join('');
          } else {
            interestsWrap.innerHTML = '<span class="interest-tag">Add your top 3 interests</span>';
          }
        }
        const langs = profile.languages || [];
        document.querySelectorAll('.lang-checkbox').forEach(cb => {
          cb.checked = langs.includes(cb.value);
        });

        const teachList = document.getElementById('skills-teach-list');
        if (teachList) {
          const list = profile.skills_teach && profile.skills_teach.length
            ? profile.skills_teach
            : (Array.isArray(profile.onboarding?.skills_teach) ? profile.onboarding.skills_teach : []);
          teachList.innerHTML = list.length
            ? list.map(s => `<li>\u2714\uFE0F ${escapeHtml(s)}</li>`).join('')
            : '<li class="text-muted">Add skills you can teach</li>';
        }
        const learnList = document.getElementById('skills-learn-list');
        if (learnList) {
          const list = profile.skills_learn && profile.skills_learn.length
            ? profile.skills_learn
            : (Array.isArray(profile.onboarding?.skills_learn) ? profile.onboarding.skills_learn : []);
          learnList.innerHTML = list.length
            ? list.map(s => `<li>\u{1F3AF} ${escapeHtml(s)}</li>`).join('')
            : '<li class="text-muted">Add skills you want to learn</li>';
        }

        const dayLabel = {
          monday: 'Monday',
          tuesday: 'Tuesday',
          wednesday: 'Wednesday',
          thursday: 'Thursday',
          friday: 'Friday',
          saturday: 'Saturday',
          sunday: 'Sunday',
        };
        const timeLabel = {
          morning: 'Morning',
          afternoon: 'Afternoon',
          evening: 'Evening',
        };
        const days = Array.isArray(profile.onboarding?.days) ? profile.onboarding.days : [];
        const times = Array.isArray(profile.onboarding?.time) ? profile.onboarding.time : [];
        const availabilityDays = document.getElementById('availability-days');
        const availabilityTime = document.getElementById('availability-time');
        if (availabilityDays) {
          availabilityDays.textContent = days.length
            ? `Days: ${days.map((d) => dayLabel[d] || d).join(', ')}`
            : 'No days selected yet';
        }
        if (availabilityTime) {
          availabilityTime.textContent = times.length
            ? `Time: ${times.map((t) => timeLabel[t] || t).join(', ')}`
            : 'No time selected yet';
        }

        const emergency = profile.emergency_contact || {};
        if (document.getElementById('emergency-name')) document.getElementById('emergency-name').value = emergency.name || '';
        if (document.getElementById('emergency-relationship')) document.getElementById('emergency-relationship').value = emergency.relationship || '';
        if (document.getElementById('emergency-country-code')) {
          document.getElementById('emergency-country-code').value = emergency.country_code || '+65';
        }
        if (document.getElementById('emergency-phone')) {
          const rawPhone = String(emergency.phone || '').trim();
          const normalizedPhone = rawPhone.replace(/\D/g, '');
          document.getElementById('emergency-phone').value = normalizedPhone;
        }
        if (document.getElementById('verify-phone-country') && document.getElementById('verify-phone-number')) {
          const profilePhone = String(profile.phone_number || '').trim();
          const countryEl = document.getElementById('verify-phone-country');
          const phoneEl = document.getElementById('verify-phone-number');
          const options = Array.from(countryEl.options || []).map((o) => o.value).filter(Boolean);
          const matchedCode = options
            .sort((a, b) => b.length - a.length)
            .find((code) => profilePhone.startsWith(code));
          if (matchedCode) {
            countryEl.value = matchedCode;
            phoneEl.value = profilePhone.slice(matchedCode.length).replace(/\D/g, '');
          } else if (profilePhone) {
            document.getElementById('verify-phone-number').value = profilePhone.replace(/\D/g, '');
          }
        }

        const safety = profile.safety || {};
        const safetyValue = document.getElementById('safety-score-value');
        const safetyFill = document.getElementById('safety-score-fill');
        const safetyBadge = document.getElementById('safety-score-badge');
        const safetyEvents = document.getElementById('safety-events');
        if (safetyValue) safetyValue.textContent = safety.score ?? '--';
        if (safetyFill && typeof safety.score === 'number') {
          safetyFill.style.width = Math.min(100, Math.max(0, safety.score)) + '%';
          if (safety.tier === 'green') safetyFill.style.background = '#22c55e';
          else if (safety.tier === 'yellow') safetyFill.style.background = '#f59e0b';
          else safetyFill.style.background = '#ef4444';
        }
        if (safetyBadge) safetyBadge.style.display = safety.trusted ? '' : 'none';
        if (safetyEvents) {
          const events = Array.isArray(safety.events) ? safety.events : [];
          safetyEvents.innerHTML = events.length
            ? events.map(e => {
                const sign = e.points > 0 ? '+' : '';
                return `<div>${sign}${e.points} ${escapeHtml(e.details || e.event_type)}</div>`;
              }).join('')
            : '<div>No recent safety events yet.</div>';
        }

        const notifications = profile.notifications || {};
        if (document.getElementById('notif-messages')) document.getElementById('notif-messages').checked = notifications.messages ?? true;
        if (document.getElementById('notif-matches')) document.getElementById('notif-matches').checked = notifications.matches ?? true;
        if (document.getElementById('notif-circles')) document.getElementById('notif-circles').checked = notifications.circles ?? true;
        if (document.getElementById('notif-challenges')) document.getElementById('notif-challenges').checked = notifications.challenges ?? false;
        if (document.getElementById('notif-badges')) document.getElementById('notif-badges').checked = notifications.badges ?? true;

        const privacy = profile.privacy || {};
        if (document.getElementById('privacy-age')) document.getElementById('privacy-age').checked = privacy.show_age ?? true;
        if (document.getElementById('privacy-location')) document.getElementById('privacy-location').checked = privacy.show_location ?? true;
        if (document.getElementById('privacy-badges')) document.getElementById('privacy-badges').checked = privacy.show_badges ?? false;
        if (document.getElementById('privacy-direct')) document.getElementById('privacy-direct').checked = privacy.allow_direct ?? true;

        const verifiedBadge = document.getElementById('verification-badge');
        const verificationTitle = document.getElementById('verification-title');
        const verificationDesc = document.getElementById('verification-desc');
        const verifiedMethod = String(profile.verified_with || '').toLowerCase();
        const verified = ['singpass', 'nric', 'email', 'phone'].includes(verifiedMethod);
        const verifiedLabelMap = {
          singpass: 'Singpass',
          nric: 'NRIC',
          email: 'Email',
          phone: 'Phone',
        };
        if (verifiedBadge) verifiedBadge.style.display = verified ? '' : 'none';
        if (verificationTitle) verificationTitle.textContent = verified ? 'Account Verified' : 'Not Verified Yet';
        if (verificationDesc) {
          verificationDesc.textContent = verified
            ? `Your identity has been verified with ${verifiedLabelMap[verifiedMethod] || profile.verified_with}`
            : 'Verify by Singpass, NRIC, email or phone number.';
        }
      }
    })
    .catch(error => {
      console.error('Error loading profile:', error);
    });
}

function updateBio(bio) {
  fetch('/api/profile', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ bio: bio }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.ok) {
      // Reload profile to update display
      loadProfile();
      // Restore UI
      const textarea = document.querySelector('.bio-edit-textarea');
      const buttonContainer = textarea ? textarea.nextSibling : null;
      if (textarea) textarea.remove();
      if (buttonContainer && buttonContainer.tagName === 'DIV') buttonContainer.remove();
      document.getElementById('bio-text').style.display = '';
      document.getElementById('edit-bio-btn').style.display = '';
    } else {
      alert('Failed to update bio');
    }
  })
  .catch(error => {
    console.error('Error updating bio:', error);
    alert('Error updating bio');
  });
}

async function saveProfile(payload) {
  try {
    const res = await fetch('/api/profile', {
      method: 'POST',
      headers: demoHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(data.error || 'Could not save changes.');
      return;
    }
    loadProfile();
  } catch (err) {
    alert('Could not save changes.');
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text ?? '';
  return div.innerHTML;
}

