﻿// Profile Page Tab Switching

document.addEventListener('DOMContentLoaded', function() {
  const tabBtns = document.querySelectorAll('.profile-tab-btn');
  const tabContents = document.querySelectorAll('.profile-tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const tabName = this.dataset.tab;

      // Remove active from all
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      // Add active to clicked
      this.classList.add('active');
      const targetContent = document.getElementById(`tab-${tabName}`);
      if (targetContent) {
        targetContent.classList.add('active');
      }

      // Scroll to top
      window.scrollTo({ top: 200, behavior: 'smooth' });
    });
  });

  // Load profile data
  loadProfile();

  // Edit Bio functionality
  const editBioBtn = document.getElementById('edit-bio-btn');
  if (editBioBtn) {
    editBioBtn.addEventListener('click', function() {
      const bioText = document.getElementById('bio-text');
      if (!bioText) return;

      const currentBio = bioText.textContent || '';
      const textarea = document.createElement('textarea');
      textarea.value = currentBio;
      textarea.className = 'bio-edit-textarea';
      textarea.rows = 4;
      textarea.style.width = '100%';
      textarea.style.marginBottom = '10px';

      const saveBtn = document.createElement('button');
      saveBtn.textContent = 'Save';
      saveBtn.className = 'btn bio-save-btn';

      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancel';
      cancelBtn.className = 'btn btn-secondary bio-cancel-btn';

      const buttonContainer = document.createElement('div');
      buttonContainer.className = 'bio-action-buttons';
      buttonContainer.appendChild(saveBtn);
      buttonContainer.appendChild(cancelBtn);

      // Replace bio text with textarea and buttons
      bioText.style.display = 'none';
      editBioBtn.style.display = 'none';
      bioText.parentNode.insertBefore(textarea, bioText);
      bioText.parentNode.insertBefore(buttonContainer, bioText);

      saveBtn.addEventListener('click', function() {
        const newBio = textarea.value.trim();
        updateBio(newBio);
      });

      cancelBtn.addEventListener('click', function() {
        // Restore original
        textarea.remove();
        buttonContainer.remove();
        bioText.style.display = '';
        editBioBtn.style.display = '';
      });
    });
  }

  document.querySelector('.btn-danger')?.addEventListener('click', function() {
    if (confirm('\u26A0\uFE0F Are you SURE you want to delete your account? This action cannot be undone.')) {
      alert('Account deletion process initiated. You will receive a confirmation email.');
    }
  });

  const mediaModal = document.getElementById('media-choice-modal');
  const mediaCameraBtn = document.getElementById('media-choice-camera');
  const mediaUploadBtn = document.getElementById('media-choice-upload');
  const mediaCancelBtn = document.getElementById('media-choice-cancel');
  let activeMediaTarget = null;

  function openMediaModal(target) {
    activeMediaTarget = target;
    if (mediaModal) {
      mediaModal.classList.add('show');
      mediaModal.setAttribute('aria-hidden', 'false');
    }
  }

  function closeMediaModal() {
    activeMediaTarget = null;
    if (mediaModal) {
      mediaModal.classList.remove('show');
      mediaModal.setAttribute('aria-hidden', 'true');
    }
  }

  if (mediaCancelBtn) mediaCancelBtn.addEventListener('click', closeMediaModal);
  if (mediaModal) {
    mediaModal.addEventListener('click', function (e) {
      if (e.target === mediaModal) closeMediaModal();
    });
  }

  const avatarBtn = document.getElementById('edit-avatar-btn');
  const bannerBtn = document.getElementById('edit-banner-btn');
  const avatarCamera = document.getElementById('avatar-input-camera');
  const avatarUpload = document.getElementById('avatar-input-upload');
  const bannerCamera = document.getElementById('banner-input-camera');
  const bannerUpload = document.getElementById('banner-input-upload');

  if (avatarBtn) avatarBtn.addEventListener('click', () => openMediaModal('avatar'));
  if (bannerBtn) bannerBtn.addEventListener('click', () => openMediaModal('banner'));

  if (mediaCameraBtn) {
    mediaCameraBtn.addEventListener('click', function () {
      if (activeMediaTarget === 'avatar' && avatarCamera) avatarCamera.click();
      if (activeMediaTarget === 'banner' && bannerCamera) bannerCamera.click();
      closeMediaModal();
    });
  }

  if (mediaUploadBtn) {
    mediaUploadBtn.addEventListener('click', function () {
      if (activeMediaTarget === 'avatar' && avatarUpload) avatarUpload.click();
      if (activeMediaTarget === 'banner' && bannerUpload) bannerUpload.click();
      closeMediaModal();
    });
  }

  async function handleAvatarUpload(input) {
    if (!input || !input.files || !input.files[0]) return;
    const form = new FormData();
    form.append('avatar', input.files[0]);
    const res = await fetch('/api/profile/avatar', { method: 'POST', body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return alert(data.error || 'Could not upload avatar.');
    const img = document.getElementById('profile-avatar');
    if (img) img.src = data.url;
  }

  async function handleBannerUpload(input) {
    if (!input || !input.files || !input.files[0]) return;
    const form = new FormData();
    form.append('banner', input.files[0]);
    const res = await fetch('/api/profile/banner', { method: 'POST', body: form });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return alert(data.error || 'Could not upload banner.');
    const cover = document.getElementById('profile-cover');
    if (cover) cover.style.backgroundImage = `url('${data.url}')`;
  }

  if (avatarCamera) avatarCamera.addEventListener('change', () => handleAvatarUpload(avatarCamera));
  if (avatarUpload) avatarUpload.addEventListener('change', () => handleAvatarUpload(avatarUpload));
  if (bannerCamera) bannerCamera.addEventListener('change', () => handleBannerUpload(bannerCamera));
  if (bannerUpload) bannerUpload.addEventListener('change', () => handleBannerUpload(bannerUpload));

  const saveLangBtn = document.getElementById('save-languages');
  if (saveLangBtn) {
    saveLangBtn.addEventListener('click', async () => {
      const langs = Array.from(document.querySelectorAll('.lang-checkbox'))
        .filter(cb => cb.checked)
        .map(cb => cb.value);
      await saveProfile({ languages: langs });
    });
  }

  const editTeach = document.getElementById('edit-skills-teach');
  if (editTeach) {
    editTeach.addEventListener('click', async () => {
      const current = document.querySelectorAll('#skills-teach-list li');
      const seed = Array.from(current).map(li => li.textContent.replace(/^[^\s]+\s*/, '')).join(', ');
      const next = prompt('Enter skills you can teach (comma-separated):', seed);
      if (next === null) return;
      const list = next.split(',').map(s => s.trim()).filter(Boolean);
      await saveProfile({ skills_teach: list });
    });
  }

  const editLearn = document.getElementById('edit-skills-learn');
  if (editLearn) {
    editLearn.addEventListener('click', async () => {
      const current = document.querySelectorAll('#skills-learn-list li');
      const seed = Array.from(current).map(li => li.textContent.replace(/^[^\s]+\s*/, '')).join(', ');
      const next = prompt('Enter skills you want to learn (comma-separated):', seed);
      if (next === null) return;
      const list = next.split(',').map(s => s.trim()).filter(Boolean);
      await saveProfile({ skills_learn: list });
    });
  }

  const reportBtn = document.getElementById('submit-report');
  if (reportBtn) {
    reportBtn.addEventListener('click', async () => {
      const reason = (document.getElementById('report-reason')?.value || '').trim();
      const date = (document.getElementById('report-date')?.value || '').trim();
      const details = (document.getElementById('report-details')?.value || '').trim();
      if (!reason || !date) return alert('Please select a reason and date.');
      const res = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: reason, incident_date: date, details: details })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return alert(data.error || 'Could not submit report.');
      alert('Report submitted. Our safety team will review it.');
      if (document.getElementById('report-reason')) document.getElementById('report-reason').value = '';
      if (document.getElementById('report-date')) document.getElementById('report-date').value = '';
      if (document.getElementById('report-details')) document.getElementById('report-details').value = '';
    });
  }

  const saveEmergency = document.getElementById('save-emergency');
  if (saveEmergency) {
    saveEmergency.addEventListener('click', async () => {
      const name = (document.getElementById('emergency-name')?.value || '').trim();
      const relationship = (document.getElementById('emergency-relationship')?.value || '').trim();
      const phone = (document.getElementById('emergency-phone')?.value || '').trim();
      await saveProfile({ emergency_contact: { name, relationship, phone } });
    });
  }

  const linkSingpass = document.getElementById('link-singpass');
  if (linkSingpass) {
    linkSingpass.addEventListener('click', async () => {
      await saveProfile({ verified_with: 'singpass' });
    });
  }
  const linkNric = document.getElementById('link-nric');
  if (linkNric) {
    linkNric.addEventListener('click', async () => {
      await saveProfile({ verified_with: 'nric' });
    });
  }

  ['notif-messages','notif-matches','notif-circles','notif-challenges','notif-badges',
   'privacy-age','privacy-location','privacy-badges','privacy-direct'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => {
        const notifications = {
          messages: !!document.getElementById('notif-messages')?.checked,
          matches: !!document.getElementById('notif-matches')?.checked,
          circles: !!document.getElementById('notif-circles')?.checked,
          challenges: !!document.getElementById('notif-challenges')?.checked,
          badges: !!document.getElementById('notif-badges')?.checked,
        };
        const privacy = {
          show_age: !!document.getElementById('privacy-age')?.checked,
          show_location: !!document.getElementById('privacy-location')?.checked,
          show_badges: !!document.getElementById('privacy-badges')?.checked,
          allow_direct: !!document.getElementById('privacy-direct')?.checked,
        };
        saveProfile({ notifications, privacy });
      });
    }
  });

  const MRT_STATIONS = [
    "Admiralty","Aljunied","Ang Mo Kio","Bartley","Bayfront","Beauty World","Bedok","Bedok North","Bedok Reservoir",
    "Bencoolen","Bendemeer","Bishan","Boon Keng","Boon Lay","Botanic Gardens","Braddell","Bras Basah","Bright Hill",
    "Bugis","Buona Vista","Buangkok","Bukit Batok","Bukit Gombak","Bukit Panjang","Caldecott","Canberra","Cashew",
    "Changi Airport","Chinatown","Choa Chu Kang","Chinese Garden","City Hall","Clarke Quay","Clementi","Commonwealth",
    "Dakota","Dhoby Ghaut","Dover","Downtown","Eunos","Expo","Farrer Park","Farrer Road","Fort Canning",
    "Gardens by the Bay","Geylang Bahru","Great World","Gul Circle","Havelock","Haw Par Villa","HarbourFront",
    "Hillview","Holland Village","Hougang","Jalan Besar","Joo Koon","Jurong East","Kaki Bukit","Kallang","Katong Park",
    "Kembangan","Kent Ridge","Khatib","King Albert Park","Kovan","Kranji","Labrador Park","Lakeside","Lavender",
    "Lentor","Little India","Lorong Chuan","MacPherson","Marina Bay","Marina South Pier","Marine Parade",
    "Marine Terrace","Marymount","Mattar","Maxwell","Mayflower","Mountbatten","Napier","Nicoll Highway","Novena",
    "one-north","Orchard","Orchard Boulevard","Outram Park","Pasir Panjang","Pasir Ris","Paya Lebar","Pioneer",
    "Potong Pasir","Promenade","Punggol","Queenstown","Raffles Place","Redhill","Rochor","Sembawang","Sengkang",
    "Serangoon","Shenton Way","Simei","Siglap","Sixth Avenue","Somerset","Springleaf","Stadium","Stevens","Tai Seng",
    "Tampines","Tampines East","Tampines West","Tan Kah Kee","Tanah Merah","Tanjong Katong","Tanjong Pagar",
    "Tanjong Rhu","Telok Ayer","Tiong Bahru","Toa Payoh","Tuas Crescent","Tuas Link","Tuas West Road",
    "Ubi","Upper Changi","Upper Thomson","Woodlands","Woodlands North","Woodlands South","Woodleigh","Yew Tee",
    "Yio Chu Kang","Yishun"
  ];

  let selectedStations = [];

  function renderProfileStations(list) {
    const container = document.getElementById('profile-mrt-options');
    if (!container) return;
    container.innerHTML = '';
    list.forEach(function (name) {
      const id = 'profile-mrt-' + name.replace(/\s+/g, '-').toLowerCase();
      const checked = selectedStations.indexOf(name) !== -1 ? 'checked' : '';
      const item = document.createElement('label');
      item.className = 'station-option';
      item.innerHTML = `
        <input type="checkbox" class="profile-station-checkbox" id="${id}" value="${name}" ${checked}>
        <span>${name}</span>
      `;
      container.appendChild(item);
    });

    container.querySelectorAll('.profile-station-checkbox').forEach(function (cb) {
      cb.addEventListener('change', function () {
        const val = cb.value;
        if (cb.checked) {
          if (selectedStations.indexOf(val) === -1) selectedStations.push(val);
        } else {
          selectedStations = selectedStations.filter(s => s !== val);
        }
      });
    });
  }

  function filterProfileStations(query) {
    const q = (query || '').toLowerCase();
    const filtered = MRT_STATIONS.filter(s => s.toLowerCase().includes(q));
    renderProfileStations(filtered);
  }

  const profileSearch = document.getElementById('profile-mrt-search');
  if (profileSearch) {
    profileSearch.addEventListener('input', function () {
      filterProfileStations(profileSearch.value);
    });
  }

  const profileSave = document.getElementById('profile-mrt-save-btn');
  if (profileSave) {
    profileSave.addEventListener('click', async () => {
      const name = selectedStations.join(', ');
      await saveProfile({ location_name: name });
      const display = document.getElementById('location-display');
      if (display && name) display.textContent = `\u{1F4CD} ${name}`;
    });
  }

  window.__setProfileStations = function (stations) {
    selectedStations = Array.isArray(stations) ? stations.slice() : [];
    renderProfileStations(MRT_STATIONS);
  };
});

function loadProfile() {
  fetch('/api/profile')
    .then(response => response.json())
    .then(data => {
      if (data.ok) {
        const profile = data.profile;
        const bioText = document.getElementById('bio-text');
        if (bioText) {
          bioText.textContent = profile.bio || '';
        }
        const connections = document.getElementById('connections-count');
        if (connections) connections.textContent = profile.connections_count ?? 0;
        const memories = document.getElementById('memories-count');
        if (memories) memories.textContent = profile.memories_count ?? 0;
        const repoints = document.getElementById('repoints-count');
        if (repoints) repoints.textContent = profile.repoints ?? 0;

        const avatar = document.getElementById('profile-avatar');
        if (avatar && profile.avatar_url) avatar.src = profile.avatar_url;
        const cover = document.getElementById('profile-cover');
        if (cover && profile.banner_url) cover.style.backgroundImage = `url('${profile.banner_url}')`;

        const locDisplay = document.getElementById('location-display');
        const onboardingStations = Array.isArray(profile.onboarding?.stations) ? profile.onboarding.stations : [];
        const storedStations = profile.location_name
          ? profile.location_name.split(',').map(s => s.trim()).filter(Boolean)
          : [];
        const stationList = onboardingStations.length ? onboardingStations : storedStations;
        if (locDisplay && stationList.length) locDisplay.textContent = `\u{1F4CD} ${stationList.join(', ')}`;
        if (stationList.length && typeof window.__setProfileStations === 'function') {
          window.__setProfileStations(stationList);
        } else if (typeof window.__setProfileStations === 'function') {
          window.__setProfileStations([]);
        }
        const langs = profile.languages || [];
        document.querySelectorAll('.lang-checkbox').forEach(cb => {
          cb.checked = langs.includes(cb.value);
        });

        const teachList = document.getElementById('skills-teach-list');
        if (teachList) {
          const list = profile.skills_teach && profile.skills_teach.length ? profile.skills_teach : [
            'Smartphone Basics', 'Cooking Tips', 'Photography'
          ];
          teachList.innerHTML = list.map(s => `<li>\u2714\uFE0F ${escapeHtml(s)}</li>`).join('');
        }
        const learnList = document.getElementById('skills-learn-list');
        if (learnList) {
          const list = profile.skills_learn && profile.skills_learn.length ? profile.skills_learn : [
            'Digital Payments', 'Traditional Crafts'
          ];
          learnList.innerHTML = list.map(s => `<li>\u{1F3AF} ${escapeHtml(s)}</li>`).join('');
        }

        const emergency = profile.emergency_contact || {};
        if (document.getElementById('emergency-name')) document.getElementById('emergency-name').value = emergency.name || '';
        if (document.getElementById('emergency-relationship')) document.getElementById('emergency-relationship').value = emergency.relationship || '';
        if (document.getElementById('emergency-phone')) document.getElementById('emergency-phone').value = emergency.phone || '';

        const notifications = profile.notifications || {};
        if (document.getElementById('notif-messages')) document.getElementById('notif-messages').checked = notifications.messages ?? true;
        if (document.getElementById('notif-matches')) document.getElementById('notif-matches').checked = notifications.matches ?? true;
        if (document.getElementById('notif-circles')) document.getElementById('notif-circles').checked = notifications.circles ?? true;
        if (document.getElementById('notif-challenges')) document.getElementById('notif-challenges').checked = notifications.challenges ?? false;
        if (document.getElementById('notif-badges')) document.getElementById('notif-badges').checked = notifications.badges ?? true;

        const privacy = profile.privacy || {};
        if (document.getElementById('privacy-age')) document.getElementById('privacy-age').checked = privacy.show_age ?? true;
        if (document.getElementById('privacy-location')) document.getElementById('privacy-location').checked = privacy.show_location ?? true;
        if (document.getElementById('privacy-badges')) document.getElementById('privacy-badges').checked = privacy.show_badges ?? false;
        if (document.getElementById('privacy-direct')) document.getElementById('privacy-direct').checked = privacy.allow_direct ?? true;

        const verifiedBadge = document.getElementById('verification-badge');
        const verificationTitle = document.getElementById('verification-title');
        const verificationDesc = document.getElementById('verification-desc');
        const verified = profile.verified_with === 'singpass' || profile.verified_with === 'nric';
        if (verifiedBadge) verifiedBadge.style.display = verified ? '' : 'none';
        if (verificationTitle) verificationTitle.textContent = verified ? 'Account Verified' : 'Not Verified Yet';
        if (verificationDesc) {
          verificationDesc.textContent = verified
            ? `Your identity has been verified with ${profile.verified_with.toUpperCase()}`
            : 'Link Singpass or add NRIC to verify your account.';
        }
      }
    })
    .catch(error => {
      console.error('Error loading profile:', error);
    });
}

function updateBio(bio) {
  fetch('/api/profile', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ bio: bio }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.ok) {
      // Reload profile to update display
      loadProfile();
      // Restore UI
      const textarea = document.querySelector('.bio-edit-textarea');
      const buttonContainer = textarea ? textarea.nextSibling : null;
      if (textarea) textarea.remove();
      if (buttonContainer && buttonContainer.tagName === 'DIV') buttonContainer.remove();
      document.getElementById('bio-text').style.display = '';
      document.getElementById('edit-bio-btn').style.display = '';
    } else {
      alert('Failed to update bio');
    }
  })
  .catch(error => {
    console.error('Error updating bio:', error);
    alert('Error updating bio');
  });
}

async function saveProfile(payload) {
  try {
    const res = await fetch('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(data.error || 'Could not save changes.');
      return;
    }
    loadProfile();
  } catch (err) {
    alert('Could not save changes.');
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text ?? '';
  return div.innerHTML;
}

