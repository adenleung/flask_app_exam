let currentStep = 1;
const totalSteps = 7;
let selectedUserType = null;
let selectedInterests = [];
let selectedTeach = [];
let selectedLearn = [];
let selectedDays = [];
let selectedTimes = [];
let selectedStations = [];
let selectedLandmarks = [];

const params = new URLSearchParams(window.location.search);
const isEditMode = params.get('edit') === '1';
const preloaded = window.preloadedOnboarding || {};

// Step 1: User Type Selection
const userTypeCards = document.querySelectorAll('.user-type-card');
const nextBtn1 = document.getElementById('next-1');

userTypeCards.forEach(card => {
  card.addEventListener('click', function() {
    userTypeCards.forEach(c => c.classList.remove('selected'));
    this.classList.add('selected');
    selectedUserType = this.dataset.type;
    nextBtn1.disabled = false;
  });
});

nextBtn1.addEventListener('click', function() {
  goToStep(2);
});

// Step 2: Interests Selection
const interestChips = document.querySelectorAll('#step-2 .interest-chip[data-interest]');
const teachChips = document.querySelectorAll('#step-3 .interest-chip[data-teach]');
const learnChips = document.querySelectorAll('#step-4 .interest-chip[data-learn]');
const nextBtn2 = document.getElementById('next-2');
const backBtn2 = document.getElementById('back-2');

function updateInterestNextButton() {
  const minCount = 3;
  if (!nextBtn2) return;
  nextBtn2.disabled = selectedInterests.length < minCount;
}

interestChips.forEach(chip => {
  chip.addEventListener('click', function() {
    const interest = this.dataset.interest;

    if (this.classList.contains('selected')) {
      this.classList.remove('selected');
      if (interest) selectedInterests = selectedInterests.filter(i => i !== interest);
    } else {
      this.classList.add('selected');
      if (interest) selectedInterests.push(interest);
    }

    updateInterestNextButton();
  });
});

nextBtn2.addEventListener('click', function() {
  goToStep(3);
});

backBtn2.addEventListener('click', function() {
  goToStep(1);
});

// Step 3: Skills I Can Teach
const backBtn3 = document.getElementById('back-3');
const nextBtn3 = document.getElementById('next-3');

function updateTeachNextButton() {
  if (!nextBtn3) return;
  nextBtn3.disabled = selectedTeach.length < 1;
}

teachChips.forEach(chip => {
  chip.addEventListener('click', function() {
    const teach = this.dataset.teach;
    if (!teach) return;
    if (this.classList.contains('selected')) {
      this.classList.remove('selected');
      selectedTeach = selectedTeach.filter(i => i !== teach);
    } else {
      this.classList.add('selected');
      selectedTeach.push(teach);
    }
    updateTeachNextButton();
  });
});

backBtn3.addEventListener('click', function() {
  goToStep(2);
});

if (nextBtn3) {
  nextBtn3.addEventListener('click', function() {
    goToStep(4);
  });
}

// Step 4: Skills I Want to Learn
const backBtn4 = document.getElementById('back-4');
const nextBtn4 = document.getElementById('next-4');

function updateLearnNextButton() {
  if (!nextBtn4) return;
  nextBtn4.disabled = selectedLearn.length < 1;
}

learnChips.forEach(chip => {
  chip.addEventListener('click', function() {
    const learn = this.dataset.learn;
    if (!learn) return;
    if (this.classList.contains('selected')) {
      this.classList.remove('selected');
      selectedLearn = selectedLearn.filter(i => i !== learn);
    } else {
      this.classList.add('selected');
      selectedLearn.push(learn);
    }
    updateLearnNextButton();
  });
});

if (backBtn4) {
  backBtn4.addEventListener('click', function() {
    goToStep(3);
  });
}

if (nextBtn4) {
  nextBtn4.addEventListener('click', function() {
    goToStep(5);
  });
}

// Step 5: Availability Selection
const dayChips = document.querySelectorAll('.day-chip');
const timeChips = document.querySelectorAll('.time-chip');
const finishBtn = document.getElementById('finish');
const backBtn5 = document.getElementById('back-5');
const nextBtn5 = document.getElementById('next-5');
const backBtn6 = document.getElementById('back-6');
const nextBtn6 = document.getElementById('next-6');
const backBtn7 = document.getElementById('back-7');

dayChips.forEach(chip => {
  chip.addEventListener('click', function() {
    const day = this.dataset.day;

    if (this.classList.contains('selected')) {
      this.classList.remove('selected');
      selectedDays = selectedDays.filter(d => d !== day);
    } else {
      this.classList.add('selected');
      selectedDays.push(day);
    }
  });
});

timeChips.forEach(chip => {
  chip.addEventListener('click', function() {
    const time = this.dataset.time;
    if (this.classList.contains('selected')) {
      this.classList.remove('selected');
      selectedTimes = selectedTimes.filter(t => t !== time);
    } else {
      this.classList.add('selected');
      selectedTimes.push(time);
    }
  });
});

if (backBtn5) {
  backBtn5.addEventListener('click', function() {
    goToStep(4);
  });
}

if (nextBtn5) {
  nextBtn5.addEventListener('click', function() {
    goToStep(6);
  });
}

if (backBtn6) {
  backBtn6.addEventListener('click', function() {
    goToStep(5);
  });
}

if (nextBtn6) {
  nextBtn6.addEventListener('click', function() {
    goToStep(7);
  });
}

if (backBtn7) {
  backBtn7.addEventListener('click', function() {
    goToStep(6);
  });
}

finishBtn.addEventListener('click', async function() {
  // Store onboarding data in the database
  var payload = {
    memberType: selectedUserType || '',
    interests: selectedInterests || [],
    skills_teach: selectedTeach || [],
    skills_learn: selectedLearn || [],
    days: selectedDays || [],
    time: selectedTimes || [],
    stations: selectedStations || [],
    landmarks: selectedLandmarks || []
  };

  try {
    var res = await fetch('/api/onboarding', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    var out = await res.json().catch(function () { return {}; });

    if (!res.ok) {
      if (res.status === 401) {
        alert('Please sign up or log in first.');
        window.location.href = '/signup';
        return;
      }
      alert(out.error || 'Could not save your onboarding details.');
      return;
    }

    // Redirect to dashboard
    window.location.href = '/dashboard';
  } catch (err) {
    alert('Could not reach the server. Please try again.');
  }
});

// Navigation Function
function goToStep(stepNumber) {
  // Hide all steps
  document.querySelectorAll('.onboarding-step').forEach(step => {
    step.classList.remove('active');
  });

  // Show current step
  document.getElementById(`step-${stepNumber}`).classList.add('active');

  // Update progress
  currentStep = stepNumber;
  document.getElementById('current-step').textContent = stepNumber;

  const progressPercent = (stepNumber / totalSteps) * 100;
  document.getElementById('progress-fill').style.width = `${progressPercent}%`;

  // Scroll to top
  window.scrollTo(0, 0);
}

// Preload selections for edit mode
document.addEventListener('DOMContentLoaded', function() {
  if (preloaded && preloaded.memberType) {
    selectedUserType = preloaded.memberType;
    userTypeCards.forEach(card => {
      if (card.dataset.type === selectedUserType) {
        card.classList.add('selected');
      }
    });
    nextBtn1.disabled = false;
  }

  if (preloaded && Array.isArray(preloaded.interests)) {
    selectedInterests = [...preloaded.interests];
    preloaded.interests.forEach(function(interest) {
      var chip = document.querySelector('.interest-chip[data-interest="' + interest + '"]');
      if (chip) chip.classList.add('selected');
    });
  }

  if (preloaded && Array.isArray(preloaded.skills_teach)) {
    selectedTeach = [...preloaded.skills_teach];
    preloaded.skills_teach.forEach(function(skill) {
      var chip = document.querySelector('.interest-chip[data-teach="' + skill + '"]');
      if (chip) chip.classList.add('selected');
    });
  }

  if (preloaded && Array.isArray(preloaded.skills_learn)) {
    selectedLearn = [...preloaded.skills_learn];
    preloaded.skills_learn.forEach(function(skill) {
      var chip = document.querySelector('.interest-chip[data-learn="' + skill + '"]');
      if (chip) chip.classList.add('selected');
    });
  }

  updateInterestNextButton();
  updateTeachNextButton();
  updateLearnNextButton();

  if (preloaded && Array.isArray(preloaded.days)) {
    selectedDays = [...preloaded.days];
    preloaded.days.forEach(function(day) {
      var chip = document.querySelector('.day-chip[data-day="' + day + '"]');
      if (chip) chip.classList.add('selected');
    });
  }

  if (preloaded && Array.isArray(preloaded.time)) {
    selectedTimes = [...preloaded.time];
    preloaded.time.forEach(function(t) {
      var chip = document.querySelector('.time-chip[data-time="' + t + '"]');
      if (chip) chip.classList.add('selected');
    });
  }

  if (preloaded && Array.isArray(preloaded.stations)) {
    selectedStations = [...preloaded.stations];
  }
});

// MRT Station Picker
const mrtStations = [
  "Admiralty","Aljunied","Ang Mo Kio","Bartley","Bayfront","Beauty World","Bedok","Bedok North","Bedok Reservoir",
  "Bencoolen","Bendemeer","Bishan","Boon Keng","Boon Lay","Botanic Gardens","Braddell","Bras Basah","Bright Hill",
  "Bugis","Buona Vista","Buangkok","Bukit Batok","Bukit Gombak","Bukit Panjang","Caldecott","Canberra","Cashew",
  "Changi Airport","Chinatown","Choa Chu Kang","Chinese Garden","City Hall","Clarke Quay","Clementi","Commonwealth",
  "Dakota","Dhoby Ghaut","Dover","Downtown","Eunos","Expo","Farrer Park","Farrer Road","Fort Canning",
  "Gardens by the Bay","Geylang Bahru","Great World","Gul Circle","Havelock","Haw Par Villa","HarbourFront",
  "Hillview","Holland Village","Hougang","Jalan Besar","Joo Koon","Jurong East","Kaki Bukit","Kallang","Katong Park",
  "Kembangan","Kent Ridge","Khatib","King Albert Park","Kovan","Kranji","Labrador Park","Lakeside","Lavender",
  "Lentor","Little India","Lorong Chuan","MacPherson","Marina Bay","Marina South Pier","Marine Parade",
  "Marine Terrace","Marymount","Mattar","Maxwell","Mayflower","Mountbatten","Napier","Nicoll Highway","Novena",
  "one-north","Orchard","Orchard Boulevard","Outram Park","Pasir Panjang","Pasir Ris","Paya Lebar","Pioneer",
  "Potong Pasir","Promenade","Punggol","Queenstown","Raffles Place","Redhill","Rochor","Sembawang","Sengkang",
  "Serangoon","Shenton Way","Simei","Siglap","Sixth Avenue","Somerset","Springleaf","Stadium","Stevens","Tai Seng",
  "Tampines","Tampines East","Tampines West","Tan Kah Kee","Tanah Merah","Tanjong Katong","Tanjong Pagar",
  "Tanjong Rhu","Telok Ayer","Tiong Bahru","Toa Payoh","Tuas Crescent","Tuas Link","Tuas West Road",
  "Ubi","Upper Changi","Upper Thomson","Woodlands","Woodlands North","Woodlands South","Woodleigh","Yew Tee",
  "Yio Chu Kang","Yishun"
];

function renderStationOptions(list, selected) {
  const container = document.getElementById('mrt-options');
  if (!container) return;
  container.innerHTML = '';
  list.forEach(function (name) {
    const id = 'mrt-' + name.replace(/\s+/g, '-').toLowerCase();
    const checked = selected.indexOf(name) !== -1 ? 'checked' : '';
    const item = document.createElement('label');
    item.className = 'station-option';
    item.innerHTML = `
      <input type="checkbox" value="${name}" ${checked}>
      <span>${name}</span>
    `;
    container.appendChild(item);
  });
  container.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
    cb.addEventListener('change', function () {
      const val = cb.value;
      if (cb.checked) {
        if (selectedStations.indexOf(val) === -1) selectedStations.push(val);
      } else {
        selectedStations = selectedStations.filter(s => s !== val);
      }
    });
  });
}

function filterStations(query) {
  const q = (query || '').toLowerCase();
  const filtered = mrtStations.filter(s => s.toLowerCase().includes(q));
  renderStationOptions(filtered, selectedStations);
}

const stationSearch = document.getElementById('mrt-search');
if (stationSearch) {
  stationSearch.addEventListener('input', function () {
    filterStations(stationSearch.value);
  });
}

if (preloaded && Array.isArray(preloaded.stations)) {
  selectedStations = [...preloaded.stations];
}

renderStationOptions(mrtStations, selectedStations);

// Landmarks
if (preloaded && Array.isArray(preloaded.landmarks)) {
  selectedLandmarks = [...preloaded.landmarks];
}

document.querySelectorAll('.picker-tab').forEach(function (btn) {
  btn.addEventListener('click', function () {
    var target = btn.getAttribute('data-picker');
    document.querySelectorAll('.picker-tab').forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.picker-panel').forEach(p => {
      p.classList.toggle('active', p.id === target);
    });
  });
});

// Landmark selection - positions are now set in HTML via inline styles
document.querySelectorAll('.landmark-dot').forEach(function (dot) {
  const name = dot.getAttribute('data-landmark');
  if (selectedLandmarks.indexOf(name) !== -1) {
    dot.classList.add('selected');
  }
  dot.addEventListener('click', function () {
    if (dot.classList.contains('selected')) {
      dot.classList.remove('selected');
      selectedLandmarks = selectedLandmarks.filter(l => l !== name);
    } else {
      dot.classList.add('selected');
      if (selectedLandmarks.indexOf(name) === -1) selectedLandmarks.push(name);
    }
  });
});

// Landmark map zoom controls
(function initLandmarkZoom() {
  const layer = document.getElementById('landmark-layer');
  const mapImg = document.getElementById('landmark-map-image');
  const overlay = layer ? layer.querySelector('.landmark-overlay') : null;
  if (!layer || !overlay) return;
  let zoom = 1;

  function applyZoom() {
    const scale = `scale(${zoom})`;
    overlay.style.transform = scale;
    if (mapImg) mapImg.style.transform = scale;
  }

  function setZoom(next) {
    zoom = Math.max(0.9, Math.min(2.2, next));
    applyZoom();
  }

  document.querySelectorAll('.map-zoom-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const action = btn.getAttribute('data-zoom');
      if (action === 'in') setZoom(zoom + 0.1);
      if (action === 'out') setZoom(zoom - 0.1);
      if (action === 'reset') setZoom(1);
    });
  });

  layer.addEventListener('wheel', function (e) {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setZoom(zoom + delta);
  });

  applyZoom();
})();