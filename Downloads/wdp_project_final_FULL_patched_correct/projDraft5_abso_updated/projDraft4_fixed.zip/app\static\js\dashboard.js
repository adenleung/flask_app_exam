// Dashboard JavaScript

// Show main dashboard after welcome screen
window.addEventListener('DOMContentLoaded', function() {
  const welcomeScreen = document.getElementById('welcome-screen');
  const mainDashboard = document.getElementById('main-dashboard');

  function demoHeaders(extra) {
    const headers = extra ? { ...extra } : {};
    const demoId = sessionStorage.getItem('demo_user_id');
    if (demoId) headers['X-Demo-User'] = demoId;
    return headers;
  }

  // Show main dashboard after 2 seconds
  setTimeout(function() {
    mainDashboard.classList.remove('hidden');
  }, 2000);

  // Remove welcome screen from DOM after animation
  setTimeout(function() {
    if (welcomeScreen) {
      welcomeScreen.remove();
    }
  }, 2500);

  const nameEl = document.getElementById('user-name');
  if (nameEl) {
    fetch('/api/session', { headers: demoHeaders() })
      .then((res) => res.ok ? res.json() : null)
      .then((data) => {
        if (data && data.logged_in && data.name) {
          nameEl.textContent = data.name;
        }
        const navAvatar = document.querySelector('img.nav-avatar');
        if (navAvatar) {
          if (data && data.logged_in && data.avatar_url) {
            navAvatar.src = data.avatar_url;
            navAvatar.dataset.sessionAvatar = '1';
          } else if (data && data.logged_in && data.name) {
            navAvatar.src = 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + encodeURIComponent(data.name);
            navAvatar.dataset.sessionAvatar = '1';
          }
        }
      })
      .catch(() => {});
  }

  const statConnections = document.getElementById('stat-connections');
  const statMemories = document.getElementById('stat-memories');
  const statRepoints = document.getElementById('stat-repoints');
  const statCircles = document.getElementById('stat-circles');
  const statBadges = document.getElementById('stat-badges');
  if (statConnections || statMemories || statRepoints || statCircles || statBadges) {
    fetch('/api/profile', { headers: demoHeaders() })
      .then((res) => res.ok ? res.json() : null)
      .then((data) => {
        if (!data || !data.ok || !data.profile) return;
        const profile = data.profile;
        if (statConnections) statConnections.textContent = profile.connections_count ?? statConnections.textContent;
        if (statMemories) statMemories.textContent = profile.memories_count ?? statMemories.textContent;
        if (statRepoints) statRepoints.textContent = profile.repoints ?? statRepoints.textContent;
        if (statCircles) statCircles.textContent = profile.circles_count ?? statCircles.textContent;
        if (statBadges) statBadges.textContent = profile.badges_count ?? statBadges.textContent;
      })
      .catch(() => {});
  }
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});
